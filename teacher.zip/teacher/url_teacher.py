from django.conf.urls import url

from teacher import views
urlpatterns = [

    url('^$',views.registerteacher,name='registerteacher'),
    url('^viewteach/',views.viewteach,name='viewteach'),

 ]
