from django.shortcuts import render
from teacher.models import Teacher
from django.http import HttpResponse
# Create your views here.
def registerteacher(request):
    if request.method == "POST":
        obj = Teacher()
        obj.t_name= request.POST.get("name")
        obj.t_email = request.POST.get("mail")
        obj.t_contact = request.POST.get("contact")
        obj.qualification = request.POST.get("qualif")
        obj.experience = request.POST.get("exp")
        obj.address= request.POST.get("add")
        obj.save()
    return render(request,'teacher/registerteacher.html')
def viewteach(request):

    # objlist = Complaint.objects.all()
    objlist = Teacher.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'teacher/viewteacher.html',context)

