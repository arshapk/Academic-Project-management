from django.conf.urls import url
from student import views
urlpatterns=\
    [
    url('^stureg/',views.studreg,name='studreg'),
    url('^viewstud/',views.viewstud,name='viewstud'),
    ]