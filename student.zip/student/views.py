from django.shortcuts import render
from student.models import Student
from django.http import HttpResponse
# Create your views here.
def studreg(request):
    if request.method == "POST":
        obj = Student()
        obj.st_name = request.POST.get("name")
        obj.st_semester = request.POST.get("sem")
        obj.st_branch = request.POST.get("branch")
        obj.st_year= request.POST.get("year")
        obj.st_contact= request.POST.get("contactw")
        obj.st_email = request.POST.get("mail")
        obj.st_batch= request.POST.get("batch")
        obj.save()
    return render(request,'student/studentreg.html')
def viewstud(request):
    # objlist = Complaint.objects.all()
    objlist = Student.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'student/viewstud.html',context)